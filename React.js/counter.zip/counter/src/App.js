import Counter from './components/counter/index.js'
import './App.css';

const App = () => {
  return <Counter />
}

export default App;
